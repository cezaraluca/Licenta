import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from 'src/app/shared.service';
import { ShowEmpComponent } from '../../show-emp/show-emp.component';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  constructor(
    private service:SharedService,
    public activatedRoute: ActivatedRoute,
    public router: Router
  ) { }

  @Input() emp: any;
  RestaurantId: string;
  RestaurantName: string;
  City: string;
  DateOfJoining: string;
  PhotoFileName: string;
  PhotoFilePath: string;

  CityList: any = [];
  RestaurantList:any=[];
  _RestaurantList:any = [];

  itemImageUrl= "http://localhost:58341//Photos/" + this.activatedRoute.snapshot.params.PhotoFileName;
  restaurant = this.activatedRoute.snapshot.params;

  ngOnInit(): void {
    // console.log(this.activatedRoute.snapshot.params);
    // console.log(this.activatedRoute.snapshot.params.RestaurantId)
    console.log(this.activatedRoute.snapshot.params);
  }

  refreshEmpList(){
    this.service.getEmpList().subscribe(data=>{
      this.RestaurantList = data;
      console.log(this.RestaurantList)
    });
  }
}
