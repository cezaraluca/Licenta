import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RestaurantComponent } from './restaurant/restaurant.component';
import { CityComponent } from './city/city.component';
import { DetailsComponent } from './restaurant/details/details/details.component';


const routes: Routes = [
{ path:'restaurant',component:RestaurantComponent },
{ path:'city',component:CityComponent },
{ path:'details', component:DetailsComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }