﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Restaurant
    {
        public int RestaurantId { get; set; }
        public string RestaurantName { get; set; }
        public string City { get; set; }
        public string DateOfJoining { get; set; }
        public string PhotoFileName { get; set; }
        public string WiFi { get; set; }
        public string CardPayment { get; set; }
        public string PetFriendly { get; set; }
        public string Music { get; set; }
        public string Events { get; set; }
        public string Delivery { get; set; }
        public string Terrace { get; set; }
        public string Booking { get; set; }
        public string Address { get; set; }
        public string Program { get; set; }
    }
}