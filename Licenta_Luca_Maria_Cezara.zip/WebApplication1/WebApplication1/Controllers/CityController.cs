﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class CityController : ApiController
    {
        public HttpResponseMessage Get()
        {
            string query = @"
                     select CityId,CityName from
                     dbo.City
                     ";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["ManagementAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);

        }

        public string Post(City city)
        {
            try
            {
                string query = @"
                         insert into dbo.City values
                         ('" + city.CityName + @"')
                         ";
                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ManagementAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Added Successfully.";
            }
            catch (Exception)
            {
                return "Failed to Add.";
            }
        }

        public string Put(City city)
        {
            try
            {
                string query = @"
                         update dbo.City set CityName=
                         '" + city.CityName + @"'
                         where CitytId=" + city.CityId + @"
                         ";
                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ManagementAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Updated Successfully.";
            }
            catch (Exception)
            {
                return "Failed to Update.";
            }
        }

        public string Delete(int id)
        {
            try
            {
                string query = @"
                         delete from dbo.City 
                         where CitytId=" + id + @"
                         ";
                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ManagementAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Deleted Successfully.";
            }
            catch (Exception)
            {
                return "Failed to Delete.";
            }
        }
    }
}
