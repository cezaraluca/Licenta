﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication1.Models;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;

namespace WebApplication1.Controllers
{
    public class RestaurantController : ApiController
    {
        public HttpResponseMessage Get()
        {
            string query = @"
                     select RestaurantId,RestaurantName, City,
                     convert(varchar(10),DateOfJoining,120) as DateOfJoining,
                     PhotoFileName, WiFi, CardPayment, PetFriendly, Music, Events, Delivery, Terrace, Booking, Address, Program
                     from
                     dbo.Restaurant
                     ";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["ManagementAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);

        }

        public string Post(Restaurant emp)
        {
            try
            {
                string query = @"
                         insert into dbo.Restaurant values
                         (
                             '" + emp.RestaurantName + @"'
                             ,'" + emp.City + @"'
                             ,'" + emp.DateOfJoining + @"'
                             ,'" + emp.PhotoFileName + @"'
                             ,'" + emp.WiFi + @"'
                             ,'" + emp.CardPayment + @"'
                             ,'" + emp.PetFriendly + @"'
                             ,'" + emp.Music + @"'
                             ,'" + emp.Events + @"'
                             ,'" + emp.Delivery + @"'
                             ,'" + emp.Terrace + @"'
                             ,'" + emp.Booking + @"'
                             ,'" + emp.Address + @"'
                             ,'" + emp.Program + @"'
                         )
                         ";
                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ManagementAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Added Successfully!";
            }
            catch (Exception)
            {
                return "Failed to Add!";
            }
        }

        public string Put(Restaurant emp)
        {
            try
            {
                string query = @"
                         update dbo.Restaurant set 
                         RestaurantName='" + emp.RestaurantName + @"',
                         City='" + emp.City + @"',
                         DateOfJoining='" + emp.DateOfJoining + @"',
                         PhotoFileName='" + emp.PhotoFileName + @"',
                         WiFi='" + emp.WiFi + @"',
                         CardPayment='" + emp.CardPayment + @"',
                         PetFriendly='" + emp.PetFriendly + @"',
                         Music='" + emp.Music + @"',
                         Events='" + emp.Events + @"',
                         Delivery='" + emp.Delivery + @"',
                         Terrace='" + emp.Terrace + @"',
                         Booking='" + emp.Booking + @"',
                         Address='" + emp.Address + @"',
                         Program='" + emp.Program + @"'
                         where RestaurantId=" + emp.RestaurantId + @"
                         ";
                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ManagementAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Updated Successfully!";
            }
            catch (Exception)
            {
                return "Failed to Update!";
            }
        }

        public string Delete(int id)
        {
            try
            {
                string query = @"
                         delete from dbo.Restaurant 
                         where RestaurantId=" + id + @"
                         ";
                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ManagementAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Deleted Successfully!";
            }
            catch (Exception)
            {
                return "Failed to Delete!";
            }
        }

        [Route("api/Restaurant/GetAllCityNames")]
        [HttpGet]

        public HttpResponseMessage GetAllCityNames()
        {
            string query = @"
                         select CityName from dbo.City 
                         ";

            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["ManagementAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Restaurant/SaveFile")]

        public string SaveFile()
        {
            try
            {
                var httpRequest = HttpContext.Current.Request;
                var postedFile = httpRequest.Files[0];
                string filename = postedFile.FileName;
                var physicalPath = HttpContext.Current.Server.MapPath("~/Photos/" + filename);

                postedFile.SaveAs(physicalPath);

                return filename;
            }
            catch (Exception)
            {
                return "anonymous.png";
            }
        }
    }
}
